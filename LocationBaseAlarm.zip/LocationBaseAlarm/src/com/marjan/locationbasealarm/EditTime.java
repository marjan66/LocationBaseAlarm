package com.marjan.locationbasealarm;

import android.widget.Toast;

public class EditTime {
	static String tm;

	public void seTime(String t) {
		tm = t;
		//Toast.makeText(EditTime.class, tm, Toast.LENGTH_LONG).show();

	}

	public String geTime() {
		return tm;
	}

}