package com.marjan.locationbasealarm;



import java.security.SecureRandom;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TimeSeting extends Activity {
	EditText hour,minute,amorpm;
	
	String time="",h,m,am;
	Context context=TimeSeting.this;
	EditTime time2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_time);
		hour=(EditText)findViewById(R.id.editText1);
		minute=(EditText)findViewById(R.id.editText2);
		amorpm=(EditText)findViewById(R.id.editText3);
		Button button= (Button)findViewById(R.id.button1);
		
	    time2=new EditTime();
		  button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				  h=hour.getText().toString();
				  m=minute.getText().toString();
				 am=amorpm.getText().toString();
				time =time.concat(h).concat(":").concat(m).concat(" ").concat(setamorpm(am));
				Toast.makeText(TimeSeting.this,time, Toast.LENGTH_LONG).show();
				time2.seTime(time);
				final Backgrond back=new Backgrond();
				
				
				if(back!=null)
				{
					
				back.SetAlarm(context);}
				else
				Toast.makeText(context, "Alarm is null", Toast.LENGTH_SHORT).show();
			
				
				time="";
				
				Intent intent = new Intent( TimeSeting.this,LocationAlarm.class);
             
				startActivity(intent);
				
			}
		});
		
		
		
	}
	private String setamorpm(String y) {
		   if(y.equals("AM")||y.equals("am"))
		       return "AM";
		   else
			   return "PM"; 
	}

}
