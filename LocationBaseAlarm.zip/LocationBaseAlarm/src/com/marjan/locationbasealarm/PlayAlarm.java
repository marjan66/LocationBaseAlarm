package com.marjan.locationbasealarm;

import java.security.SecureRandom;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.widget.Toast;

public class PlayAlarm extends Service {

	MediaPlayer mp;

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mp = MediaPlayer.create(getApplicationContext(), R.raw.iphones);
		//Toast.makeText(PlayAlarm.this,"Sucses", Toast.LENGTH_LONG).show();
		
	}

	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		
		
		mp.setLooping(true);
		mp.start();
		Intent i = new Intent( PlayAlarm.this,LocationTest.class);
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(i);
		//Toast.makeText(PlayAlarm.this,"recive", Toast.LENGTH_LONG).show();
		return START_STICKY;
	}
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (mp != null) {
			mp.release();
			mp = null;
		}
	}

}
