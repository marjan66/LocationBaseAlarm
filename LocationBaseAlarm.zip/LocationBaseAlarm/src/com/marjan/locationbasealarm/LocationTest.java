package com.marjan.locationbasealarm;





import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class LocationTest extends Activity {
	private static final long MINIMUM_DISTANCE_CHANGE_FOR_UPDATES = 10; // in Meters
    private static final long MINIMUM_TIME_BETWEEN_UPDATES = 1000*5; // in Milliseconds
     
    protected LocationManager locationManager;
    Button dis;
    int counter=0;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
    	// TODO Auto-generated method stub
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.location);
    	locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        dis =(Button)findViewById(R.id.distro);
        dis.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				  onDestroy();
				startActivity(new Intent(LocationTest.this,LocationAlarm.class));
				
			}
		});
        locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                MINIMUM_TIME_BETWEEN_UPDATES,
                MINIMUM_DISTANCE_CHANGE_FOR_UPDATES,
                new MyLocationListener()
        );
        
     
        
    }
     @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	 locationManager.removeUpdates(new MyLocationListener());
    	 super.onDestroy();
    	
    }
     @Override
    protected void onPause() {
    	// TODO Auto-generated method stub
    	 locationManager.removeUpdates(new MyLocationListener());
    	 super.onPause();
    	
    }
     @Override
    protected void onStop() {
    	// TODO Auto-generated method stub
    	 locationManager.removeUpdates(new MyLocationListener());
    	 super.onStop();
    	
    }
     private class MyLocationListener implements LocationListener {
		 
	        public void onLocationChanged(Location location) {
         String message = String.format(
	                    " Location \n Longitude: %1$s \n Latitude: %2$s",
	                    location.getLongitude(), location.getLatitude()
	                  
	            );
             counter++;
             if(counter>=5) 
             {
            	 stopService(new Intent(LocationTest.this,
							PlayAlarm.class));
            	 locationManager.removeUpdates(new MyLocationListener());
            	 counter=0;
             }
             else     
               Toast.makeText(LocationTest.this, message+"    "+counter, Toast.LENGTH_SHORT).show();
	        }
	 
	        public void onStatusChanged(String s, int i, Bundle b) {
	            Toast.makeText(LocationTest.this, "Provider status changed",
	                    Toast.LENGTH_SHORT).show();
	        }
	 
	        public void onProviderDisabled(String s) {
	            Toast.makeText(LocationTest.this,
	                    "Provider disabled by the user. GPS turned off",
	                    Toast.LENGTH_SHORT).show();
	        }
	 
	        public void onProviderEnabled(String s) {
	            Toast.makeText(LocationTest.this,
	                    "Provider enabled by the user. GPS turned on",
	                    Toast.LENGTH_SHORT).show();
     }
	 
	    }


}
