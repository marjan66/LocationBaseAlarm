package com.marjan.locationbasealarm;



import java.security.SecureRandom;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LocationAlarm extends Activity {

	Button start, cancel, setAlarm;
	TextView operant;
	EditText ruselt;

	Context context = LocationAlarm.this;
	private Backgrond alarm;

	int x, y, z;
	String s, s1;
	SecureRandom sr = new SecureRandom();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alarm_manager);
		cancel = (Button) findViewById(R.id.cancel);

		setAlarm = (Button) findViewById(R.id.setAlarm);
		operant = (TextView) findViewById(R.id.operatn);
		ruselt = (EditText) findViewById(R.id.result);

		alarm = new Backgrond();

		Intent intent = getIntent();
		x = sr.nextInt(20000000);
		y = sr.nextInt(20000000);

		operant.setText("" + x + "+" + y);

		setAlarm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				startActivity(new Intent(LocationAlarm.this,
						TimeSeting.class));

			}
		});

		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
			
				s = ruselt.getText().toString();

				z = x + y;
				s1 = s1.valueOf(z);

				if (s.equals(s1)) {
					ruselt.setText("");
					stopService(new Intent(LocationAlarm.this,
							PlayAlarm.class));
				} else {
					x = sr.nextInt(2000);
					y = sr.nextInt(2000);

					operant.setText("" + x + "+" + y);
					ruselt.setText("");

				}

			}
		});

	}

}
